import Image from "next/image";
import Header from "./components/Header";
import 'bootstrap/dist/css/bootstrap.min.css'
import './style.css'
import Hero from "./sections/Hero";
import Products from "./sections/Products";
import Footer from "./components/Footer";
export default function Home() {
  return (
    <>
      <Hero />
      <Products/>
      <Footer/>
    </>
  );
}
