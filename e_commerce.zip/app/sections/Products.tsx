"use client"

import React from 'react'
import PrimaryButton from '../components/PrimaryButton'
import { faFilter } from '@fortawesome/free-solid-svg-icons'
import ProductCard from '../components/ProductCard'
import { productCardData } from '../data'

function Products() {


    return (
        <section className='products-section my-[40px] mx-auto container'>
            <div className="products-opts flex lg:justify-between">
                <div className='btns-filter flex items-center gap-[30px]'>
                    <button className="font-bold  text-[#1E2832] text-[16px]">All Products</button>
                    <button className='text-[#1E2832] text-[16px]'>t-shirt</button>
                    <button className='text-[#1E2832] text-[16px]'>Hoodies</button>
                    <button className='text-[#1E2832] text-[16px]'>Jacket</button>
                </div>
                <PrimaryButton name='filter' iconItem={faFilter} />
            </div>
            <div className="flex flex-wrap  -m-4 mt-[40px] products-wrapper">
                {
                    productCardData.map((cardData) => (
                        <div className="lg:w-1/4 md:w-1/2 px-2 w-full product mb-5 hover:shadow-2xl duration-200 hover:mt-[-10px] py-2 " key={cardData.id}>
                            <ProductCard {...cardData} />
                        </div>
                    ))
                }
            </div>

        </section>
    )
}

export default Products
